/* (c) Sinelabore Software Tools GmbH - All rights reserved. Reproduction, modification,
   use or disclosure to third parties without express
   authority is forbidden. Generator running in demo mode!
   Please purchase a license if you want to use this software in projects.
 */

/* Command line options: -p ssc -E sm.xml   */
/* This file is generated from sm.xml - do not edit manually  */
/* Generated on: Sat Mar 20 21:42:40 CET 2021 / Version 5.0.6b3 */




#ifndef __SM_EXT_H__ 
#define __SM_EXT_H__ 

/*Events which can be sent to the state-machine  */
typedef enum
{
	evTimeout=0U,
	SM_NO_MSG
} SM_EVENT_T;


#endif
