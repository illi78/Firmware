#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "sm_ext.h"


typedef struct {
	SM_EVENT_T msg;
	uint8_t counter;
}USER_EVENT_T;
	
